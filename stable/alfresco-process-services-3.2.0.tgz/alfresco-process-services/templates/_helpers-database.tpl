{{/*
Compute the database URL

Usage: include "alfresco-process-services.database.url" $

*/}}
{{- define "alfresco-process-services.database.url" -}}
  {{- with .Values }}
  {{- if .url }}
    {{- hasPrefix "jdbc:" .url | ternary .url (printf "jdbc:%s" .url) }}
  {{- else if .enabled }}
    {{- $pg_host := (include "postgres.fullname" $) }}
    {{- $pg_port := .primary.service.ports.postgresql | default 5432 }}
    {{- $pg_url := printf "postgresql://%s:%d/%s" $pg_host (int $pg_port) .auth.database }}
    {{- printf "jdbc:%s" $pg_url }}
  {{- else }}
    {{- fail "You must either set an (external) URL or enable embedded DB" }}
  {{- end }}
  {{- end }}
{{- end -}}
