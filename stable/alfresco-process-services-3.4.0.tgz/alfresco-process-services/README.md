# alfresco-process-services

![Version: 3.4.0](https://img.shields.io/badge/Version-3.4.0-informational?style=flat-square) ![AppVersion: 26.2.0](https://img.shields.io/badge/AppVersion-26.2.0-informational?style=flat-square)

A Helm chart for Alfresco Process Services

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Alfresco |  |  |

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://alfresco.github.io/alfresco-helm-charts/ | alfresco-activiti | 0.14.0 |
| https://alfresco.github.io/alfresco-helm-charts/ | alfresco-activiti-admin | 0.15.0 |
| https://alfresco.github.io/alfresco-helm-charts/ | alfresco-common | 5.1.0 |
| https://alfresco.github.io/alfresco-helm-charts/ | elasticsearch(elastic) | 0.7.0 |
| https://alfresco.github.io/alfresco-helm-charts/ | apsdb(postgres) | 0.7.0 |
| https://alfresco.github.io/alfresco-helm-charts/ | admindb(postgres) | 0.7.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| admindb.auth.database | string | `"activiti-admin"` |  |
| admindb.auth.enablePostgresUser | bool | `false` |  |
| admindb.auth.password | string | `"alfresco"` |  |
| admindb.auth.resources.limits.cpu | string | `"1"` |  |
| admindb.auth.resources.limits.memory | string | `"1Gi"` |  |
| admindb.auth.resources.requests.cpu | string | `"0.1"` |  |
| admindb.auth.resources.requests.memory | string | `"250Mi"` |  |
| admindb.auth.username | string | `"alfresco"` |  |
| admindb.enabled | bool | `true` |  |
| admindb.image.pullPolicy | string | `"IfNotPresent"` |  |
| admindb.image.repository | string | `"postgres"` |  |
| admindb.image.tag | string | `"17.9"` |  |
| admindb.nameOverride | string | `"postgresql-aps-admin"` |  |
| admindb.primary.service.name | string | `"postgresql-aps-admin"` |  |
| admindb.url | string | `nil` | Set an external database JDBS URL for APS admin app |
| alfresco-activiti-admin.database.existingConfigMap.keys.driver | string | `"ACTIVITI_ADMIN_DATABASE_DRIVER"` |  |
| alfresco-activiti-admin.database.existingConfigMap.keys.url | string | `"ACTIVITI_ADMIN_DATABASE_URL"` |  |
| alfresco-activiti-admin.database.existingConfigMap.name | string | `"alfresco-process-services-infrastructure"` |  |
| alfresco-activiti-admin.database.existingSecret.keys.password | string | `"ACTIVITI_ADMIN_DATABASE_PASSWORD"` |  |
| alfresco-activiti-admin.database.existingSecret.keys.username | string | `"ACTIVITI_ADMIN_DATABASE_USERNAME"` |  |
| alfresco-activiti-admin.database.existingSecret.name | string | `"alfresco-infrastructure-auth"` |  |
| alfresco-activiti-admin.envFromExistingConfigMap | string | `"alfresco-process-services-admin"` |  |
| alfresco-activiti-admin.image.repository | string | `"quay.io/alfresco/alfresco-process-services-admin"` |  |
| alfresco-activiti-admin.image.tag | string | `"26.2.0"` |  |
| alfresco-activiti-admin.ingress.enabled | bool | `true` |  |
| alfresco-activiti-admin.livenessProbe.path | string | `"/activiti-admin/actuator/health/liveness"` | Make sure to set `livenessProbe.path` to `/activiti-admin/ if you're using a version of APS prior to 24.3.0 |
| alfresco-activiti-admin.readinessProbe.path | string | `"/activiti-admin/actuator/health/readiness"` | Make sure to set `readinessProbe.path` to `/activiti-admin/` if you're using a version of APS prior to 24.3.0 |
| alfresco-activiti.database.existingConfigMap.keys.driver | string | `"ACTIVITI_DATABASE_DRIVER"` |  |
| alfresco-activiti.database.existingConfigMap.keys.url | string | `"ACTIVITI_DATABASE_URL"` |  |
| alfresco-activiti.database.existingConfigMap.name | string | `"alfresco-process-services-infrastructure"` |  |
| alfresco-activiti.database.existingSecret.keys.password | string | `"ACTIVITI_DATABASE_PASSWORD"` |  |
| alfresco-activiti.database.existingSecret.keys.username | string | `"ACTIVITI_DATABASE_USERNAME"` |  |
| alfresco-activiti.database.existingSecret.name | string | `"alfresco-infrastructure-auth"` |  |
| alfresco-activiti.envFromExistingConfigMap | string | `"alfresco-process-services"` |  |
| alfresco-activiti.image.repository | string | `"quay.io/alfresco/alfresco-process-services"` |  |
| alfresco-activiti.image.tag | string | `"26.2.0"` |  |
| alfresco-activiti.ingress.enabled | bool | `true` |  |
| alfresco-activiti.license.secretName | string | `nil` | Name of the secret where the APS license can be found |
| alfresco-activiti.livenessProbe.path | string | `"/activiti-app/actuator/health/liveness"` | Make sure to set `livenessProbe.path` to `/activiti-app/app/rest/locale` if you're using a version of APS prior to 24.3.0 |
| alfresco-activiti.nameOverride | string | `"alfresco-activiti"` |  |
| alfresco-activiti.persistence.accessModes[0] | string | `"ReadWriteOnce"` |  |
| alfresco-activiti.persistence.baseSize | string | `"20Gi"` | Initial default size of dynamically provisioned storage |
| alfresco-activiti.persistence.data | object | `{"mountPath":"/usr/local/data","subPath":"alfresco-process-services/process-data"}` | Where to mount data into the container |
| alfresco-activiti.persistence.enabled | bool | `true` | Persist processEngine data |
| alfresco-activiti.persistence.existingClaim | string | `nil` | Define if you want to reuse an already existing PVC |
| alfresco-activiti.persistence.storageClass | string | `nil` | Define if you already have a custom storage class defined for dynamically provisioned storage |
| alfresco-activiti.readinessProbe.path | string | `"/activiti-app/actuator/health/readiness"` | Make sure to set `readinessProbe.path` to `/activiti-app/app/rest/locale` if you're using a version of APS prior to 24.3.0 |
| alfresco-activiti.replicacount | int | `1` |  |
| alfresco-activiti.security.cors.enabled | bool | `true` |  |
| alfresco-activiti.security.csrf.enabled | bool | `true` |  |
| apsdb.auth.database | string | `"activiti"` |  |
| apsdb.auth.enablePostgresUser | bool | `false` |  |
| apsdb.auth.password | string | `"alfresco"` |  |
| apsdb.auth.username | string | `"alfresco"` |  |
| apsdb.enabled | bool | `true` |  |
| apsdb.image.pullPolicy | string | `"IfNotPresent"` |  |
| apsdb.image.repository | string | `"postgres"` |  |
| apsdb.image.tag | string | `"17.9"` |  |
| apsdb.nameOverride | string | `"postgresql-aps"` |  |
| apsdb.primary.resources.limits.cpu | string | `"8"` |  |
| apsdb.primary.resources.limits.memory | string | `"8Gi"` |  |
| apsdb.primary.resources.requests.cpu | string | `"500m"` |  |
| apsdb.primary.resources.requests.memory | string | `"1Gi"` |  |
| apsdb.primary.service.name | string | `"postgresql-aps"` |  |
| apsdb.url | string | `nil` | Set an external database JDBS URL for APS |
| elasticsearch.elasticsearch.image.repository | string | `"elasticsearch"` |  |
| elasticsearch.elasticsearch.image.tag | string | `"8.17.3"` |  |
| elasticsearch.elasticsearch.persistence.baseSize | string | `"4Gi"` |  |
| elasticsearch.elasticsearch.persistence.enabled | bool | `true` |  |
| elasticsearch.enabled | bool | `true` |  |
| elasticsearch.nameOverride | string | `"elasticsearch"` |  |
| elasticsearch.url | string | `nil` | Set an external Elasticsearch URL for APS |
| global.known_urls[0] | string | `"http://localhost"` |  |
| global.known_urls[1] | string | `"https://localhost"` |  |
| global.security.allowInsecureImages | bool | `true` |  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
