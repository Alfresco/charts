# postgres

![Version: 0.8.0](https://img.shields.io/badge/Version-0.8.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 17.9](https://img.shields.io/badge/AppVersion-17.9-informational?style=flat-square)

WARNING: This chart is meant to ease initial deployment for TESTING purposes.
DO NOT use this chart in any staging, or production environment. It has very
limited options. It is not meant to be configurable and we do not aim at
making it particularly secure or add features to it. Its SOLE goal is to allow
for quickly spinning up an Alfresco platform on kubernetes, any issue that
does not affect this is likely to not be fixed. For any other purpose, make
sure to deploy your own enterprise grade PostgreSQL instance and configure
Alfresco charts to point to it.

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://alfresco.github.io/alfresco-helm-charts/ | alfresco-common | 5.1.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| additionalLabels | object | `{}` | Additional labels to be added to all resources (deployments, statefulsets, services, pods, etc.) Example:   Product: k8s   Environment: DEV |
| auth.database | string | `"alfresco"` |  |
| auth.existingSecret | string | `nil` |  |
| auth.password | string | `"alfresco"` |  |
| auth.username | string | `"alfresco"` |  |
| global.additionalLabels | object | `{}` | Global additional labels that can be set at parent/umbrella chart level These will be merged with chart-level additionalLabels, with chart-level taking precedence |
| image.pullPolicy | string | `"IfNotPresent"` |  |
| image.repository | string | `"postgres"` |  |
| image.tag | string | `"17.9"` |  |
| imagePullSecrets | list | `[]` | List of image pull secrets to use when pulling images Example:   imagePullSecrets:     - name: my-registry-secret |
| livenessProbe.exec.command[0] | string | `"/bin/sh"` |  |
| livenessProbe.exec.command[1] | string | `"-c"` |  |
| livenessProbe.exec.command[2] | string | `"-e"` |  |
| livenessProbe.exec.command[3] | string | `"exec pg_isready -d $POSTGRES_DB -U $POSTGRES_USER"` |  |
| livenessProbe.failureThreshold | int | `3` |  |
| livenessProbe.initialDelaySeconds | int | `30` |  |
| livenessProbe.periodSeconds | int | `10` |  |
| livenessProbe.timeoutSeconds | int | `3` |  |
| nameOverride | string | `"postgresql"` |  |
| podSecurityContext.fsGroup | int | `1000` |  |
| primary.extendedConfiguration | string | `"max_connections=250\nshared_buffers=512MB\neffective_cache_size=2GB\nwal_level=minimal\nmax_wal_senders=0\nmax_replication_slots=0\nlog_min_messages=LOG\n"` |  |
| primary.persistence.accessModes | list | `["ReadWriteOnce"]` | defines type of access required by the persistent volume [Access_Modes] (https://kubernetes.io/docs/concepts/storage/persistent-volumes/#access-modes) |
| primary.persistence.baseSize | string | `"8Gi"` |  |
| primary.persistence.data.mountPath | string | `"/var/lib/postgresql/data"` |  |
| primary.persistence.data.subPath | string | `"alfresco-content-services/database-data"` |  |
| primary.persistence.enabled | bool | `false` |  |
| primary.persistence.existingClaim | string | `nil` | provide an existing persistent volume claim name to persist SQL data Make sure the root folder has the appropriate permissions/ownership set. |
| primary.persistence.storageClass | string | `nil` | set the storageClass to use for dynamic provisioning. setting it to null means "default storageClass". |
| primary.resources.limits.cpu | string | `"8"` |  |
| primary.resources.limits.memory | string | `"8Gi"` |  |
| primary.resources.requests.cpu | string | `"500m"` |  |
| primary.resources.requests.memory | string | `"1Gi"` |  |
| primary.service.annotations | object | `{}` |  |
| primary.service.name | string | `"postgresql"` | used for naming pvc |
| primary.service.ports.postgresql | int | `5432` |  |
| primary.shmVolume.enabled | bool | `true` |  |
| primary.shmVolume.sizeLimit | string | `"256Mi"` | Size of the memory-backed /dev/shm volume for PostgreSQL dynamic shared memory (parallel queries). The container runtime default of 64Mi is too small for heavy workloads and causes "could not resize shared memory segment ... No space left on device". Charged to the pod memory cgroup, so keep it comfortably below primary.resources.limits.memory. |
| readinessProbe.exec.command[0] | string | `"/bin/sh"` |  |
| readinessProbe.exec.command[1] | string | `"-c"` |  |
| readinessProbe.exec.command[2] | string | `"-e"` |  |
| readinessProbe.exec.command[3] | string | `"exec pg_isready -d $POSTGRES_DB -U $POSTGRES_USER"` |  |
| readinessProbe.failureThreshold | int | `3` |  |
| readinessProbe.initialDelaySeconds | int | `5` |  |
| readinessProbe.periodSeconds | int | `10` |  |
| readinessProbe.timeoutSeconds | int | `3` |  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
